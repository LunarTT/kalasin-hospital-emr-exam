import React, { useState } from 'react';
import { Hospital, User, Stethoscope, Users, Search } from 'lucide-react';
import { PatientProfile } from './components/PatientProfile';
import { StudentDashboard } from './components/StudentDashboard';
import { AttendingDashboard } from './components/AttendingDashboard';
import { AllergyWarningDialog } from './components/AllergyWarningDialog';
import { PatientSidebar, Patient } from './components/PatientSidebar';
import { PastRecordsSidebar } from './components/PastRecordsSidebar';

const MOCK_PATIENTS: Patient[] = [
  {
    id: '1',
    name: "คุณสมชาย ใจดี",
    age: 45,
    gender: "ชาย",
    hn: "67-12345",
    vitals: { bp: "120/80", hr: 80, rr: 20, bt: 37.0, wt: 75, ht: 170 },
    allergies: ["Penicillin", "Amoxicillin (Anaphylaxis)"],
    status: 'in-progress',
    time: '09:00',
    isNewPatient: false,
    pastRecords: [
      {
        id: 'r1',
        date: '12 ก.ย. 2566',
        department: 'OPD อายุรกรรม',
        diagnosis: 'J03.9 Acute tonsillitis, unspecified',
        doctor: 'อ.พญ. สมศรี รักษาดี',
        treatments: ['Amoxicillin 500mg', 'Paracetamol 500mg']
      },
      {
        id: 'r2',
        date: '5 ม.ค. 2566',
        department: 'OPD อายุรกรรม',
        diagnosis: 'J06.9 Acute upper respiratory infection, unspecified',
        doctor: 'นพ. สมบูรณ์ เก่งเวช',
        treatments: ['Paracetamol 500mg', 'CPM 4mg']
      }
    ]
  },
  {
    id: '2',
    name: "คุณสมหญิง รักดี",
    age: 32,
    gender: "หญิง",
    hn: "67-12346",
    vitals: { bp: "110/70", hr: 75, rr: 18, bt: 36.8, wt: 55, ht: 160 },
    allergies: [],
    status: 'waiting',
    time: '09:30',
    isNewPatient: true,
    pastRecords: []
  },
  {
    id: '3',
    name: "คุณตา บุญมา",
    age: 68,
    gender: "ชาย",
    hn: "67-12347",
    vitals: { bp: "140/90", hr: 85, rr: 22, bt: 37.2, wt: 65, ht: 165 },
    allergies: ["Sulfa"],
    status: 'waiting',
    time: '10:00',
    isNewPatient: false,
    pastRecords: [
      {
        id: 'r3',
        date: '10 ต.ค. 2565',
        department: 'OPD ศัลยกรรมกระดูก',
        diagnosis: 'M15.9 Polyosteoarthritis, unspecified',
        doctor: 'อ.นพ. แข็งแรง กระดูกดี',
        treatments: ['Celecoxib 200mg', 'กายภาพบำบัด']
      }
    ]
  },
  {
    id: '4',
    name: "ด.ช. เก่งกาจ สามารถ",
    age: 8,
    gender: "ชาย",
    hn: "67-12348",
    vitals: { bp: "100/60", hr: 90, rr: 24, bt: 38.5, wt: 25, ht: 120 },
    allergies: ["Aspirin", "Ibuprofen"],
    status: 'waiting',
    time: '10:30',
    isNewPatient: true,
    pastRecords: []
  }
];

// Simple rule engine for demo
const CHECK_ALLERGY = (med: string, patientAllergies: string[]) => {
  const normalizedMed = med.toLowerCase();
  return patientAllergies.some(allergy => {
    const normalizedAllergy = allergy.toLowerCase().split(' ')[0]; // Basic check e.g. "Amoxicillin (Anaphylaxis)" -> "amoxicillin"
    return normalizedMed.includes(normalizedAllergy) || 
           (normalizedMed.includes('amoxicillin') && normalizedAllergy.includes('penicillin')); // Cross-reactivity demo
  });
};

export default function App() {
  const [role, setRole] = useState<'student' | 'attending'>('student');
  
  // UI States
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isPastRecordsOpen, setIsPastRecordsOpen] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState<string>('1');
  
  // Data State Map to hold notes for each patient
  const [patientDataMap, setPatientDataMap] = useState<Record<string, any>>({
    '1': {
      student: {
        cc: 'เจ็บคอ มีไข้ มา 3 วัน',
        pi: '3 วันก่อน มีไข้สูง หนาวสั่น ไอบ่อย มีเสมหะสีเหลือง ซื้อยาทานเองไม่ดีขึ้น กลืนน้ำลายลำบาก',
        pe: 'T 38.5°C, P 100/min, R 20/min, BP 120/80 mmHg. Pharynx injected, tonsils enlarged 3+ with exudate both sides.',
        assessment: 'Acute Exudative Tonsillitis',
        plan: '1. Amoxicillin (500) 1 tab po tid pc\n2. Paracetamol (500) 1 tab po prn q 4-6 hr for fever\n3. Warm water gargle'
      },
      attending: { summary: '', diagnosis: '' },
      prescriptions: []
    }
  });

  const currentPatient = MOCK_PATIENTS.find(p => p.id === selectedPatientId) || MOCK_PATIENTS[0];

  // Helper to safely get current data
  const getCurrentData = () => {
    return patientDataMap[selectedPatientId] || {
      student: { cc: '', pi: '', pe: '', assessment: '', plan: '' },
      attending: { summary: '', diagnosis: '' },
      prescriptions: []
    };
  };

  const currentData = getCurrentData();

  // Updaters that update the global map for the *current* patient
  const setStudentNotes = (updater: any) => {
    setPatientDataMap(prev => {
      const data = prev[selectedPatientId] || { student: { cc: '', pi: '', pe: '', assessment: '', plan: '' }, attending: { summary: '', diagnosis: '' }, prescriptions: [] };
      const newNotes = typeof updater === 'function' ? updater(data.student) : updater;
      return { ...prev, [selectedPatientId]: { ...data, student: newNotes } };
    });
  };

  const setAttendingNotes = (updater: any) => {
    setPatientDataMap(prev => {
      const data = prev[selectedPatientId] || { student: { cc: '', pi: '', pe: '', assessment: '', plan: '' }, attending: { summary: '', diagnosis: '' }, prescriptions: [] };
      const newNotes = typeof updater === 'function' ? updater(data.attending) : updater;
      return { ...prev, [selectedPatientId]: { ...data, attending: newNotes } };
    });
  };

  const setPrescriptions = (updater: any) => {
    setPatientDataMap(prev => {
      const data = prev[selectedPatientId] || { student: { cc: '', pi: '', pe: '', assessment: '', plan: '' }, attending: { summary: '', diagnosis: '' }, prescriptions: [] };
      const newPrescriptions = typeof updater === 'function' ? updater(data.prescriptions) : updater;
      return { ...prev, [selectedPatientId]: { ...data, prescriptions: newPrescriptions } };
    });
  };
  
  // Modal state
  const [allergyModalOpen, setAllergyModalOpen] = useState(false);
  const [attemptedMed, setAttemptedMed] = useState<string | null>(null);

  const handlePrescribe = (med: string) => {
    if (CHECK_ALLERGY(med, currentPatient.allergies)) {
      setAttemptedMed(med);
      setAllergyModalOpen(true);
    } else {
      setPrescriptions((prev: string[]) => [...prev, med]);
    }
  };

  const handleConfirmAllergy = () => {
    if (attemptedMed) {
      setPrescriptions((prev: string[]) => [...prev, attemptedMed]);
    }
    setAllergyModalOpen(false);
    setAttemptedMed(null);
  };

  const handleCancelAllergy = () => {
    setAllergyModalOpen(false);
    setAttemptedMed(null);
  };

  const handleRemovePrescription = (med: string) => {
    setPrescriptions((prev: string[]) => prev.filter(p => p !== med));
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-100 font-sans overflow-hidden relative">
      {/* Top Header */}
      <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Hospital className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-800 leading-tight">ระบบเวชระเบียน โรงพยาบาลมหาวิทยาลัยกาฬสินธุ์</h1>
            <p className="text-xs text-slate-500 font-medium tracking-wide">Teaching Dashboard (EMR)</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          {/* Patient Queue & Search Toggle */}
          <div className="flex items-center gap-3">
            <div 
              onClick={() => setIsSidebarOpen(true)}
              className="relative hidden md:block cursor-pointer group"
            >
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 group-hover:text-blue-500 transition-colors" />
              <input 
                type="text" 
                placeholder="ค้นหาผู้ป่วย..." 
                className="w-48 pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm cursor-pointer hover:bg-white hover:border-blue-300 focus:outline-none transition-all"
                readOnly
              />
            </div>
            
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-semibold transition-colors border border-slate-200"
            >
              <Users className="h-4 w-4" />
              คิวรอตรวจ
              <span className="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full shadow-sm">
                {MOCK_PATIENTS.length}
              </span>
            </button>
          </div>

          <div className="w-px h-8 bg-slate-200"></div>

          {/* Role Switcher */}
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 shadow-inner">
            <button
              onClick={() => setRole('student')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                role === 'student'
                  ? 'bg-white text-blue-700 shadow-sm border border-slate-200'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <User className="h-4 w-4" />
              นักศึกษาแพทย์
            </button>
            <button
              onClick={() => setRole('attending')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                role === 'attending'
                  ? 'bg-white text-emerald-700 shadow-sm border border-slate-200'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <Stethoscope className="h-4 w-4" />
              อาจารย์แพทย์
            </button>
          </div>
        </div>
      </header>

      {/* Patient Profile Banner */}
      <PatientProfile 
        patient={currentPatient} 
        onOpenPastRecords={() => setIsPastRecordsOpen(true)} 
      />

      {/* Main Content Area */}
      <main className="flex-1 min-h-0 relative">
        {role === 'student' ? (
          <StudentDashboard
            notes={currentData.student}
            setNotes={setStudentNotes}
          />
        ) : (
          <AttendingDashboard
            studentNotes={currentData.student}
            attendingNotes={currentData.attending}
            setAttendingNotes={setAttendingNotes}
            prescriptions={currentData.prescriptions}
            onPrescribe={handlePrescribe}
            onRemovePrescription={handleRemovePrescription}
          />
        )}
      </main>

      {/* Patient Queue Sidebar */}
      <PatientSidebar 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
        patients={MOCK_PATIENTS}
        currentPatientId={selectedPatientId}
        onSelectPatient={(id) => setSelectedPatientId(id)}
      />

      {/* Past Records Sidebar */}
      <PastRecordsSidebar
        isOpen={isPastRecordsOpen}
        onClose={() => setIsPastRecordsOpen(false)}
        patient={currentPatient}
      />

      {/* Allergy Warning Overlay */}
      <AllergyWarningDialog
        isOpen={allergyModalOpen}
        medication={attemptedMed}
        patientAllergies={currentPatient.allergies}
        onConfirm={handleConfirmAllergy}
        onCancel={handleCancelAllergy}
      />
    </div>
  );
}
