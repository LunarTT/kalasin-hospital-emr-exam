import React from "react";
import {
  User,
  Activity,
  FileText,
  ClipboardList,
} from "lucide-react";

interface StudentDashboardProps {
  notes: {
    cc: string;
    pi: string;
    pe: string;
    assessment: string;
    plan: string;
  };
  setNotes: React.Dispatch<React.SetStateAction<any>>;
}

export function StudentDashboard({
  notes,
  setNotes,
}: StudentDashboardProps) {
  const handleChange = (field: string, value: string) => {
    setNotes((prev: any) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="flex h-full p-4 gap-4 bg-slate-50">
      {/* Left Column: History & Physical */}
      <div className="flex-1 flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-blue-50/50 border-b border-slate-100 px-4 py-3 flex items-center gap-2 shrink-0">
          <User className="h-5 w-5 text-blue-600" />
          <h3 className="font-semibold text-slate-800">
            History & Physical Examination
          </h3>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="flex flex-col h-32">
            <label className="text-sm font-medium text-slate-600 mb-1">
              Chief Complaint (CC)
            </label>
            <textarea
              className="flex-1 resize-none w-full border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              placeholder="อาการสำคัญที่มาโรงพยาบาล..."
              value={notes.cc}
              onChange={(e) =>
                handleChange("cc", e.target.value)
              }
            />
          </div>

          <div className="flex flex-col h-48">
            <label className="text-sm font-medium text-slate-600 mb-1">
              Present Illness (PI)
            </label>
            <textarea
              className="flex-1 resize-none w-full border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              placeholder="ประวัติการเจ็บป่วยปัจจุบัน..."
              value={notes.pi}
              onChange={(e) =>
                handleChange("pi", e.target.value)
              }
            />
          </div>

          <div className="flex flex-col h-48">
            <label className="text-sm font-medium text-slate-600 mb-1 flex items-center gap-2">
              <Activity className="h-4 w-4" /> Physical
              Examination (PE)
            </label>
            <textarea
              className="flex-1 resize-none w-full border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              placeholder="ผลการตรวจร่างกาย..."
              value={notes.pe}
              onChange={(e) =>
                handleChange("pe", e.target.value)
              }
            />
          </div>
        </div>
      </div>

      {/* Right Column: Assessment & Plan */}
      <div className="flex-1 flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-purple-50/50 border-b border-slate-100 px-4 py-3 flex items-center gap-2 shrink-0">
          <ClipboardList className="h-5 w-5 text-purple-600" />
          <h3 className="font-semibold text-slate-800">
            Assessment & Plan
          </h3>
        </div>

        <div className="flex-1 flex flex-col overflow-y-auto p-4 space-y-4">
          <div className="flex flex-col h-48">
            <label className="text-sm font-medium text-slate-600 mb-1">
              Assessment / Provisional Diagnosis
            </label>
            <textarea
              className="flex-1 resize-none w-full border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
              placeholder="การประเมินและวินิจฉัยโรคเบื้องต้น..."
              value={notes.assessment}
              onChange={(e) =>
                handleChange("assessment", e.target.value)
              }
            />
          </div>

          <div className="flex flex-col flex-1">
            <label className="text-sm font-medium text-slate-600 mb-1">
              Management Plan
            </label>
            <textarea
              className="flex-1 resize-none w-full border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
              placeholder="แผนการรักษา (ยา, หัตถการ, การนัดหมาย)..."
              value={notes.plan}
              onChange={(e) =>
                handleChange("plan", e.target.value)
              }
            />
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50 shrink-0 flex justify-end">
          <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium shadow-sm transition-colors">
            บันทึกแบบร่าง (Draft)
          </button>
        </div>
      </div>
    </div>
  );
}