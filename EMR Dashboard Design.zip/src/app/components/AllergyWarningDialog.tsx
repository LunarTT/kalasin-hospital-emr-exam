import React from 'react';
import { AlertOctagon, XCircle } from 'lucide-react';

interface AllergyWarningDialogProps {
  isOpen: boolean;
  medication: string | null;
  patientAllergies: string[];
  onConfirm: () => void;
  onCancel: () => void;
}

export function AllergyWarningDialog({
  isOpen,
  medication,
  patientAllergies,
  onConfirm,
  onCancel
}: AllergyWarningDialogProps) {
  if (!isOpen || !medication) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div 
        className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border-2 border-red-500 animate-in fade-in zoom-in duration-200"
        role="dialog"
        aria-modal="true"
      >
        <div className="bg-red-600 px-6 py-4 flex items-center gap-3">
          <AlertOctagon className="h-8 w-8 text-white animate-pulse" />
          <h2 className="text-xl font-bold text-white">แจ้งเตือน: ตรวจพบประวัติแพ้ยา!</h2>
        </div>
        
        <div className="p-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <p className="text-slate-700 text-lg mb-2">
              คุณกำลังสั่งยา <strong className="text-red-700">{medication}</strong>
            </p>
            <p className="text-slate-700 text-lg">
              ซึ่งผู้ป่วยมีประวัติแพ้ยากลุ่ม: <strong className="text-red-700">{patientAllergies.join(', ')}</strong>
            </p>
          </div>

          <p className="text-slate-600 text-sm mb-6">
            หากคุณต้องการสั่งยานี้ โปรดยืนยันว่าคุณทราบถึงประวัติการแพ้ยานี้แล้ว หรือยกเลิกเพื่อเลือกยาตัวอื่น
          </p>

          <div className="flex gap-3 justify-end">
            <button
              onClick={onCancel}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-medium flex items-center gap-2 transition-colors border border-slate-300"
            >
              <XCircle className="h-5 w-5 text-slate-600" />
              ยกเลิกการสั่งยา
            </button>
            <button
              onClick={onConfirm}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold shadow-sm transition-colors"
            >
              ยืนยันการสั่งยา (Override)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
