import React, { useState } from 'react';
import { X, Search, Clock, AlertTriangle, User, ChevronRight } from 'lucide-react';

export interface PastRecord {
  id: string;
  date: string;
  department: string;
  diagnosis: string;
  doctor: string;
  treatments: string[];
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  hn: string;
  vitals: { bp: string; hr: number; rr: number; bt: number; wt: number; ht: number };
  allergies: string[];
  status: 'waiting' | 'in-progress' | 'completed';
  time: string;
  isNewPatient: boolean;
  pastRecords: PastRecord[];
}

interface PatientSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  patients: Patient[];
  currentPatientId: string;
  onSelectPatient: (id: string) => void;
}

export function PatientSidebar({ isOpen, onClose, patients, currentPatientId, onSelectPatient }: PatientSidebarProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPatients = patients.filter(p => 
    p.name.includes(searchQuery) || p.hn.includes(searchQuery)
  );

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 transition-opacity" onClick={onClose} />
      <div className="fixed inset-y-0 right-0 w-96 bg-white shadow-2xl z-50 flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-300">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <h2 className="text-lg font-bold text-slate-800">คิวผู้ป่วยรอตรวจ</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-4 border-b border-slate-100 bg-white">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="ค้นหาชื่อ หรือ HN..."
              className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-50/50">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider pl-1 mb-2">รายชื่อผู้ป่วย ({filteredPatients.length})</div>
          
          {filteredPatients.map(patient => (
            <div
              key={patient.id}
              onClick={() => {
                onSelectPatient(patient.id);
                onClose();
              }}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                currentPatientId === patient.id 
                  ? 'bg-blue-50/50 border-blue-400 shadow-sm ring-1 ring-blue-400' 
                  : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-sm'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${currentPatientId === patient.id ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>
                    <User className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-800 text-sm">{patient.name}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <div className="text-xs text-slate-500 font-medium">HN: {patient.hn}</div>
                      {patient.isNewPatient && (
                        <span className="text-[9px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-sm font-bold">NEW</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-xs font-medium text-slate-500 bg-white px-2 py-1 rounded-md border border-slate-100 shadow-sm">
                  <Clock className="h-3 w-3" />
                  {patient.time}
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-2">
                <div className="flex gap-2">
                  <span className={`text-[10px] px-2 py-1 rounded-md font-bold tracking-wide ${
                    patient.status === 'in-progress' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                    patient.status === 'waiting' ? 'bg-slate-100 text-slate-600 border border-slate-200' :
                    'bg-emerald-100 text-emerald-700 border border-emerald-200'
                  }`}>
                    {patient.status === 'in-progress' ? 'กำลังตรวจ' : 'รอตรวจ'}
                  </span>
                  {patient.allergies.length > 0 && (
                    <span className="text-[10px] px-2 py-1 rounded-md font-bold tracking-wide bg-red-100 text-red-700 border border-red-200 flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> มีประวัติแพ้ยา
                    </span>
                  )}
                </div>
                <ChevronRight className={`h-4 w-4 ${currentPatientId === patient.id ? 'text-blue-500' : 'text-slate-300'}`} />
              </div>
            </div>
          ))}
          
          {filteredPatients.length === 0 && (
            <div className="text-center py-10 flex flex-col items-center justify-center text-slate-400">
              <Search className="h-8 w-8 mb-2 opacity-20" />
              <div className="text-sm">ไม่พบรายชื่อผู้ป่วยที่ค้นหา</div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
