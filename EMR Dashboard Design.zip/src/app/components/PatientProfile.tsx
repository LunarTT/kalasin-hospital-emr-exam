import React from 'react';
import { AlertTriangle, AlertCircle, History, UserPlus } from 'lucide-react';

interface PatientProfileProps {
  patient: {
    name: string;
    age: number;
    gender: string;
    hn: string;
    vitals: { bp: string; hr: number; rr: number; bt: number; wt: number; ht: number };
    allergies: string[];
    isNewPatient: boolean;
    pastRecords: any[];
  };
  onOpenPastRecords?: () => void;
}

export function PatientProfile({ patient, onOpenPastRecords }: PatientProfileProps) {
  return (
    <div className="bg-white border-b border-slate-200 shadow-sm shrink-0 flex items-center justify-between px-6 py-3">
      <div className="flex gap-8 items-center h-full">
        {/* Patient Basic Info */}
        <div className="flex flex-col justify-center">
          <div className="flex items-baseline gap-3">
            <h2 className="text-xl font-bold text-slate-800">{patient.name}</h2>
            <span className="text-sm font-medium text-slate-500">HN: {patient.hn}</span>
            {patient.isNewPatient && (
              <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border border-emerald-200">New Patient</span>
            )}
          </div>
          <div className="text-sm text-slate-600 mt-1">
            อายุ {patient.age} ปี | เพศ{patient.gender} | น้ำหนัก {patient.vitals.wt} กก. | ส่วนสูง {patient.vitals.ht} ซม.
          </div>
        </div>

        {/* Vitals */}
        <div className="hidden lg:flex gap-4 items-center bg-slate-50 px-4 py-2 rounded-md border border-slate-100">
          <div className="text-xs">
            <span className="text-slate-400 block">BP</span>
            <span className="font-semibold text-slate-700">{patient.vitals.bp}</span>
          </div>
          <div className="text-xs">
            <span className="text-slate-400 block">HR</span>
            <span className="font-semibold text-slate-700">{patient.vitals.hr}</span>
          </div>
          <div className="text-xs">
            <span className="text-slate-400 block">RR</span>
            <span className="font-semibold text-slate-700">{patient.vitals.rr}</span>
          </div>
          <div className="text-xs">
            <span className="text-slate-400 block">BT</span>
            <span className="font-semibold text-slate-700">{patient.vitals.bt}°C</span>
          </div>
        </div>
      </div>

      {/* Actions and Alerts */}
      <div className="flex items-center gap-4">
        
        {/* Past Records Button */}
        {patient.pastRecords && patient.pastRecords.length > 0 ? (
          <button 
            onClick={onOpenPastRecords}
            className="flex items-center gap-2 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-sm font-bold border border-blue-200 transition-colors shadow-sm"
          >
            <History className="h-4 w-4" />
            ประวัติการรักษาเดิม
            <span className="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full shadow-sm ml-1">
              {patient.pastRecords.length}
            </span>
          </button>
        ) : (
          <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 text-slate-500 rounded-lg text-sm font-medium border border-slate-200">
            <UserPlus className="h-4 w-4" />
            ผู้ป่วยใหม่ (ไม่มีประวัติ)
          </div>
        )}

        {/* Allergies Highlight Box */}
        {patient.allergies.length > 0 ? (
          <div className="bg-red-50 border-2 border-red-500 rounded-lg px-4 py-2 flex items-center gap-3 shadow-sm max-w-[20rem]">
            <AlertTriangle className="text-red-600 h-6 w-6 shrink-0 animate-pulse" />
            <div className="min-w-0">
              <div className="text-[10px] font-bold text-red-600 uppercase tracking-wider mb-0.5">ระวัง! ประวัติแพ้ยา</div>
              <div className="text-sm font-bold text-red-700 truncate" title={patient.allergies.join(', ')}>
                {patient.allergies.join(', ')}
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-green-50 border border-green-200 rounded-lg px-4 py-2 flex items-center gap-3 max-w-[12rem]">
             <AlertCircle className="text-green-500 h-5 w-5 shrink-0" />
             <span className="text-sm font-medium text-green-700 truncate">ไม่มีประวัติแพ้ยา</span>
          </div>
        )}
      </div>
    </div>
  );
}
