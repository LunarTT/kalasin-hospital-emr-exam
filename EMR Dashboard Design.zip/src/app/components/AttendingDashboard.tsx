import React, { useState } from 'react';
import { Stethoscope, CheckCircle, FileText, Pill, Plus, X, Search } from 'lucide-react';

interface AttendingDashboardProps {
  studentNotes: {
    cc: string;
    pi: string;
    pe: string;
    assessment: string;
    plan: string;
  };
  attendingNotes: {
    summary: string;
    diagnosis: string;
  };
  setAttendingNotes: React.Dispatch<React.SetStateAction<any>>;
  prescriptions: string[];
  onPrescribe: (medication: string) => void;
  onRemovePrescription: (medication: string) => void;
}

export function AttendingDashboard({
  studentNotes,
  attendingNotes,
  setAttendingNotes,
  prescriptions,
  onPrescribe,
  onRemovePrescription
}: AttendingDashboardProps) {
  const [medInput, setMedInput] = useState('');

  const handleMedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (medInput.trim()) {
      onPrescribe(medInput.trim());
      setMedInput('');
    }
  };

  const handleChange = (field: string, value: string) => {
    setAttendingNotes((prev: any) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="flex h-full w-full p-4 gap-4 bg-slate-100">
      
      {/* Left Column: Student Notes (Read-only) */}
      <div className="w-1/3 flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden shrink-0">
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex items-center gap-2 shrink-0">
          <FileText className="h-5 w-5 text-slate-500" />
          <h3 className="font-semibold text-slate-700 text-sm">บันทึกของนักศึกษาแพทย์ (Read-only)</h3>
        </div>
        
        <div className="flex-1 overflow-y-auto p-5 space-y-6 bg-slate-50/50">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Chief Complaint</h4>
            <div className="text-sm text-slate-800 bg-white p-3 rounded border border-slate-100 min-h-[3rem]">{studentNotes.cc || '-'}</div>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Present Illness</h4>
            <div className="text-sm text-slate-800 bg-white p-3 rounded border border-slate-100 min-h-[5rem]">{studentNotes.pi || '-'}</div>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Physical Examination</h4>
            <div className="text-sm text-slate-800 bg-white p-3 rounded border border-slate-100 min-h-[5rem]">{studentNotes.pe || '-'}</div>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Assessment & Plan</h4>
            <div className="text-sm text-slate-800 bg-white p-3 rounded border border-slate-100">
              <div className="font-medium text-purple-700 mb-2">Assessment: {studentNotes.assessment || '-'}</div>
              <div>Plan: {studentNotes.plan || '-'}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Attending Action Panel */}
      <div className="flex-1 flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-emerald-50 border-b border-emerald-100 px-4 py-3 flex items-center gap-2 shrink-0">
          <Stethoscope className="h-5 w-5 text-emerald-600" />
          <h3 className="font-bold text-emerald-900 text-base">Attending Physician Documentation & Orders</h3>
        </div>
        
        <div className="flex-1 flex flex-col overflow-y-auto p-5 gap-5">
          {/* Summary */}
          <div className="flex flex-col">
            <label className="text-sm font-semibold text-slate-700 mb-1 flex items-center gap-2">
              สรุปประวัติและการตรวจร่างกาย (Attending Summary)
            </label>
            <textarea
              className="resize-none h-28 border border-slate-300 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
              placeholder="อาจารย์แพทย์พิมพ์สรุปประวัติที่สำคัญ..."
              value={attendingNotes.summary}
              onChange={(e) => handleChange('summary', e.target.value)}
            />
          </div>

          {/* Diagnosis */}
          <div className="flex flex-col">
            <label className="text-sm font-semibold text-slate-700 mb-1">Final Diagnosis (ICD-10)</label>
            <input
              type="text"
              className="border border-slate-300 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none w-full"
              placeholder="e.g., J03.9 Acute tonsillitis, unspecified"
              value={attendingNotes.diagnosis}
              onChange={(e) => handleChange('diagnosis', e.target.value)}
            />
          </div>

          {/* Prescriptions */}
          <div className="flex flex-col flex-1 min-h-[14rem]">
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <Pill className="h-4 w-4" /> สั่งยา (Medication Orders)
              </label>
              <span className="text-xs text-slate-500">ระบบจะตรวจสอบประวัติแพ้ยาอัตโนมัติ</span>
            </div>
            
            <div className="border border-slate-200 rounded-lg flex-1 flex flex-col bg-slate-50 overflow-hidden">
              {/* Med Input Form */}
              <form onSubmit={handleMedSubmit} className="flex p-3 border-b border-slate-200 bg-white gap-2 shrink-0">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    className="pl-9 pr-3 py-2 w-full border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="พิมพ์ชื่อยาที่ต้องการสั่ง (เช่น Paracetamol, Amoxicillin)..."
                    value={medInput}
                    onChange={(e) => setMedInput(e.target.value)}
                  />
                </div>
                <button
                  type="submit"
                  disabled={!medInput.trim()}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Plus className="h-4 w-4" /> สั่งยา
                </button>
              </form>

              {/* Prescribed Meds List */}
              <div className="flex-1 overflow-y-auto p-3">
                {prescriptions.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400">
                    <Pill className="h-8 w-8 mb-2 opacity-20" />
                    <p className="text-sm">ยังไม่มีรายการยา</p>
                  </div>
                ) : (
                  <ul className="space-y-2">
                    {prescriptions.map((med, idx) => (
                      <li key={idx} className="flex items-center justify-between bg-white p-3 rounded-md border border-slate-200 shadow-sm">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="h-5 w-5 text-emerald-500" />
                          <span className="font-medium text-slate-800">{med}</span>
                        </div>
                        <button
                          onClick={() => onRemovePrescription(med)}
                          className="text-slate-400 hover:text-red-500 p-1 rounded-full hover:bg-red-50 transition-colors"
                          title="ลบรายการยา"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 border-t border-slate-200 bg-white shrink-0 flex justify-end gap-3">
          <button className="px-6 py-2 border border-slate-300 text-slate-700 rounded-md text-sm font-medium hover:bg-slate-50 transition-colors">
            บันทึกแบบร่าง (Draft)
          </button>
          <button className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-sm font-medium shadow-sm transition-colors flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            ลงนามและเสร็จสิ้น (Sign & Submit)
          </button>
        </div>
      </div>
    </div>
  );
}
