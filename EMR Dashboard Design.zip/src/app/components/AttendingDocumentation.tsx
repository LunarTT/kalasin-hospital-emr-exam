import { useState } from 'react';
import { Search, Plus, X } from 'lucide-react';

interface AttendingDocumentationProps {
  onMedicationAdd: (medicationName: string) => boolean;
}

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
}

interface Diagnosis {
  id: string;
  code: string;
  description: string;
}

export function AttendingDocumentation({ onMedicationAdd }: AttendingDocumentationProps) {
  const [additionalComments, setAdditionalComments] = useState('');
  const [peNotes, setPeNotes] = useState('');
  const [diagnosisSearch, setDiagnosisSearch] = useState('');
  const [diagnoses, setDiagnoses] = useState<Diagnosis[]>([
    { id: '1', code: 'E11.9', description: 'Type 2 diabetes mellitus' },
  ]);
  const [medicationInput, setMedicationInput] = useState('');
  const [medications, setMedications] = useState<Medication[]>([
    { id: '1', name: 'Metformin', dosage: '500mg 1 tab', frequency: 'PC (เช้า-เย็น)' },
  ]);

  const handleAddMedication = () => {
    if (!medicationInput.trim()) return;

    const canAdd = onMedicationAdd(medicationInput);
    
    if (canAdd) {
      const newMed: Medication = {
        id: Date.now().toString(),
        name: medicationInput,
        dosage: '',
        frequency: '',
      };
      setMedications([...medications, newMed]);
      setMedicationInput('');
    }
  };

  const handleRemoveMedication = (id: string) => {
    setMedications(medications.filter(med => med.id !== id));
  };

  const handleAddDiagnosis = () => {
    if (!diagnosisSearch.trim()) return;
    
    const newDx: Diagnosis = {
      id: Date.now().toString(),
      code: diagnosisSearch,
      description: '',
    };
    setDiagnoses([...diagnoses, newDx]);
    setDiagnosisSearch('');
  };

  return (
    <div className="bg-white rounded-lg shadow-md border-2 border-blue-200">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-4 rounded-t-lg">
        <h2 className="text-lg font-bold flex items-center gap-2">
          👨‍⚕️ บันทึกและคำสั่งอาจารย์ (Attending Doctor)
        </h2>
        <p className="text-sm text-blue-100 mt-1">
          พื้นที่สำหรับอาจารย์แพทย์พิมพ์และสั่งการ
        </p>
      </div>

      {/* Content - Editable */}
      <div className="p-5 space-y-5">
        {/* Additional Comments */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            💬 ความเห็นเพิ่มเติม / สรุปประวัติโดยอาจารย์
          </h3>
          <textarea
            value={additionalComments}
            onChange={(e) => setAdditionalComments(e.target.value)}
            placeholder="บันทึกความเห็นเพิ่มเติม หรือสรุปประวัติผู้ป่วย..."
            className="w-full min-h-[100px] p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y"
          />
        </div>

        {/* Physical Examination Notes */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            🩺 ผลการตรวจร่างกาย (PE)
          </h3>
          <textarea
            value={peNotes}
            onChange={(e) => setPeNotes(e.target.value)}
            placeholder="บันทึกผลการตรวจร่างกายโดยละเอียด..."
            className="w-full min-h-[100px] p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y"
          />
        </div>

        {/* Final Diagnosis */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            🔍 การวินิจฉัยขั้นสุดท้าย (Final Diagnosis)
          </h3>
          
          {/* ICD-10 Search */}
          <div className="mb-3">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={diagnosisSearch}
                  onChange={(e) => setDiagnosisSearch(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddDiagnosis()}
                  placeholder="ค้นหารหัส ICD-10..."
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                onClick={handleAddDiagnosis}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                เพิ่ม
              </button>
            </div>
          </div>

          {/* Diagnosis List */}
          <div className="space-y-2">
            {diagnoses.map((dx) => (
              <div key={dx.id} className="bg-white border border-blue-300 rounded-lg p-3 flex items-center justify-between">
                <div>
                  <span className="font-bold text-blue-900">📌 {dx.code}</span>
                  {dx.description && <span className="text-gray-700 ml-2">- {dx.description}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Medication Orders */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            💊 คำสั่งการรักษา / สั่งยา (Medication Order)
          </h3>

          {/* Medication Input */}
          <div className="mb-3">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Plus className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={medicationInput}
                  onChange={(e) => setMedicationInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddMedication()}
                  placeholder="พิมพ์ชื่อยาเพื่อสั่ง... (เช่น Amoxicillin 500mg)"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                onClick={handleAddMedication}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                สั่งยา
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              💡 ลองพิมพ์ "Amoxicillin" เพื่อทดสอบระบบเตือนการแพ้ยา
            </p>
          </div>

          {/* Medication List */}
          <div className="space-y-2">
            {medications.map((med) => (
              <div key={med.id} className="bg-white border border-green-300 rounded-lg p-3 flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-green-700">💊</span>
                    <span className="font-semibold text-gray-900">{med.name}</span>
                    {med.dosage && <span className="text-gray-700">{med.dosage}</span>}
                    {med.frequency && <span className="text-gray-600">{med.frequency}</span>}
                  </div>
                </div>
                <button
                  onClick={() => handleRemoveMedication(med.id)}
                  className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                  title="ลบยา"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Editable Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
          <p className="text-sm text-blue-800">
            ✏️ <span className="font-semibold">ส่วนนี้เป็นพื้นที่สำหรับอาจารย์แพทย์</span> - สามารถแก้ไขและสั่งการได้
          </p>
        </div>
      </div>
    </div>
  );
}
