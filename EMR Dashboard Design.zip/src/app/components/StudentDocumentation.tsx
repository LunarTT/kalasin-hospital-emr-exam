interface StudentData {
  studentName: string;
  chiefComplaint: string[];
  physicalExam: string[];
  provisionalDx: string;
  proposedPlan: string;
}

interface StudentDocumentationProps {
  student: StudentData;
}

export function StudentDocumentation({ student }: StudentDocumentationProps) {
  return (
    <div className="bg-white rounded-lg shadow-md border-2 border-gray-200">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white px-5 py-4 rounded-t-lg">
        <h2 className="text-lg font-bold flex items-center gap-2">
          🧑‍🎓 บันทึกของนักศึกษาแพทย์ (Med Student)
        </h2>
        <p className="text-sm text-purple-100 mt-1">
          ผู้บันทึก: {student.studentName} - อ่านได้อย่างเดียว
        </p>
      </div>

      {/* Content - Read-only */}
      <div className="p-5 space-y-5 bg-gray-50">
        {/* Chief Complaint & Present Illness */}
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            📝 อาการสำคัญและประวัติ (CC & PI)
          </h3>
          <div className="space-y-2">
            {student.chiefComplaint.map((complaint, index) => (
              <div key={index} className="flex items-start gap-2 text-gray-700">
                <span className="text-purple-600 mt-1">•</span>
                <span>{complaint}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Physical Examination */}
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            🩺 ผลการตรวจร่างกาย (PE)
          </h3>
          <div className="space-y-2">
            {student.physicalExam.map((exam, index) => (
              <div key={index} className="flex items-start gap-2 text-gray-700">
                <span className="text-purple-600 mt-1">•</span>
                <span>{exam}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Provisional Diagnosis */}
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            🔍 การวินิจฉัยเบื้องต้น (Provisional Dx)
          </h3>
          <div className="text-gray-500 italic">
            {student.provisionalDx || '(ยังไม่ได้บันทึก)'}
          </div>
        </div>

        {/* Proposed Plan */}
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            📋 แผนการรักษาเบื้องต้น (Proposed Plan)
          </h3>
          <div className="flex items-start gap-2 text-gray-700">
            <span className="text-purple-600 mt-1">•</span>
            <span>{student.proposedPlan}</span>
          </div>
        </div>

        {/* Read-only Notice */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-center">
          <p className="text-sm text-purple-800">
            🔒 <span className="font-semibold">ส่วนนี้เป็นบันทึกของนักศึกษา</span> - อาจารย์สามารถอ่านได้อย่างเดียว
          </p>
        </div>
      </div>
    </div>
  );
}
