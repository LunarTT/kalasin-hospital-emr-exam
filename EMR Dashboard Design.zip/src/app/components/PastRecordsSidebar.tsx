import React from 'react';
import { X, Calendar, Stethoscope, Pill, FileText, Activity } from 'lucide-react';
import { Patient } from './PatientSidebar';

interface PastRecordsSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  patient: Patient;
}

export function PastRecordsSidebar({ isOpen, onClose, patient }: PastRecordsSidebarProps) {
  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 transition-opacity" onClick={onClose} />
      <div className="fixed inset-y-0 right-0 w-[450px] bg-white shadow-2xl z-50 flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-300">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-blue-50">
          <div>
            <h2 className="text-lg font-bold text-blue-900 flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-600" />
              ประวัติการรักษาเดิม
            </h2>
            <p className="text-sm text-blue-700 font-medium mt-1">{patient.name} (HN: {patient.hn})</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-blue-100 rounded-full text-blue-600 transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">
          {patient.pastRecords.length === 0 ? (
             <div className="h-full flex flex-col items-center justify-center text-slate-400">
              <FileText className="h-12 w-12 mb-3 opacity-20" />
              <div className="text-base font-medium text-slate-600">ผู้ป่วยใหม่</div>
              <div className="text-sm mt-1">ยังไม่มีประวัติการรักษาในระบบ</div>
            </div>
          ) : (
             <div className="relative border-l-2 border-slate-200 ml-3 space-y-8 pb-4">
               {patient.pastRecords.map((record) => (
                 <div key={record.id} className="relative pl-6">
                   {/* Timeline dot */}
                   <div className="absolute w-4 h-4 bg-blue-500 rounded-full -left-[9px] top-1 border-4 border-white shadow-sm" />
                   
                   {/* Record Card */}
                   <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                         <div className="flex items-center gap-2 text-blue-700 font-bold text-sm">
                            <Calendar className="w-4 h-4" /> {record.date}
                         </div>
                         <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">{record.department}</span>
                      </div>
                      
                      <div className="space-y-4">
                         <div>
                            <div className="text-xs text-slate-500 font-semibold mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                              <Activity className="w-3.5 h-3.5"/> Diagnosis
                            </div>
                            <div className="text-sm text-slate-800 font-medium bg-slate-50 p-2 rounded-md border border-slate-100">
                              {record.diagnosis}
                            </div>
                         </div>
                         
                         {record.treatments.length > 0 && (
                            <div>
                              <div className="text-xs text-slate-500 font-semibold mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                                <Pill className="w-3.5 h-3.5"/> Treatments
                              </div>
                              <div className="flex flex-wrap gap-1.5">
                                {record.treatments.map((t, i) => (
                                   <span key={i} className="text-xs bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-1 rounded-md font-medium">
                                     {t}
                                   </span>
                                ))}
                              </div>
                            </div>
                         )}
                         
                         <div className="text-xs text-slate-500 flex items-center gap-1.5 pt-3 mt-2 border-t border-slate-100 font-medium">
                            <Stethoscope className="w-3.5 h-3.5 text-slate-400"/> Attending: {record.doctor}
                         </div>
                      </div>
                   </div>
                 </div>
               ))}
             </div>
          )}
        </div>
      </div>
    </>
  );
}
